package com.example.floatingai

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.util.Base64
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val ui = Handler(Looper.getMainLooper())
    private val history = JSONArray()
    private val MODEL = "claude-sonnet-5-5"
    private var bx = 40; private var by = 300
    private var pendingImage: String? = null
    private lateinit var attachBtn: Button

    companion object { var instance: FloatingService? = null }

    fun onImage(b64: String) { ui.post { pendingImage = b64; attachBtn.text = "📎✓" } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, focusable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        if (focusable) WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val ch = "floating_ai"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Floating AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Floating AI aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (android.os.Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildBubble(); buildPanel()
        wm.addView(bubble, lp(dp(56), dp(56), false).apply { x = bx; y = by })
    }

    private fun buildBubble() {
        bubble = TextView(this).apply {
            text = "AI"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#D97757")) }
            elevation = 12f
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { v, e ->
            val p = v.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = ox + dx; p.y = oy + dy; bx = p.x; by = p.y; wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP -> if (!moved) openPanel()
            }
            true
        }
    }

    private fun buildPanel() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.WHITE); setStroke(dp(1), Color.LTGRAY) }
            elevation = 16f
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "Asisten AI"; textSize = 16f; setTextColor(Color.BLACK) },
            LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "–"; setOnClickListener { closePanel() } })
        header.addView(Button(this).apply { text = "✕"; setOnClickListener { stopSelf() } })
        panel.addView(header)
        log = TextView(this).apply { setTextColor(Color.BLACK); textSize = 14f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(log) }
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply { hint = "Tulis pesan…"; maxLines = 3; setTextColor(Color.BLACK) }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        attachBtn = Button(this).apply {
            text = "📷"
            setOnClickListener {
                startActivity(Intent(this@FloatingService, PickImageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        row.addView(attachBtn)
        row.addView(Button(this).apply { text = "Kirim"; setOnClickListener { send() } })
        panel.addView(row)
    }

    private fun openPanel() {
        wm.removeView(bubble)
        val m = resources.displayMetrics
        wm.addView(panel, lp(minOf(dp(340), m.widthPixels - dp(24)), dp(440), true)
            .apply { x = dp(12); y = maxOf(by - dp(100), dp(40)) })
    }

    private fun closePanel() {
        wm.removeView(panel)
        wm.addView(bubble, lp(dp(56), dp(56), false).apply { x = bx; y = by })
    }

    private fun append(s: String) { log.append(s + "\n\n"); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun send() {
        val text = input.text.toString().trim()
        val img = pendingImage
        if (text.isEmpty() && img == null) return
        input.setText(""); pendingImage = null; attachBtn.text = "📷"
        append("Anda: " + (if (img != null) "📷 " else "") + text)
        val content: Any = if (img != null) JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64").put("media_type", "image/jpeg").put("data", img)))
            .put(JSONObject().put("type", "text").put("text", if (text.isEmpty()) "Jawab soal pada gambar ini." else text))
        else text
        history.put(JSONObject().put("role", "user").put("content", content))
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
        thread {
            val reply = try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                val body = JSONObject().put("model", MODEL).put("max_tokens", 2048)
                    .put("system", "Kamu asisten AI yang melayang di layar ponsel. Jawab singkat dan jelas, dalam bahasa pengguna.")
                    .put("messages", history)
                    .put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                val resp = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                if (ok) {
                    val arr = JSONObject(resp).getJSONArray("content"); val sb = StringBuilder()
                    for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("type") == "text") sb.append(o.getString("text")) }
                    val t = sb.toString().ifEmpty { "(tidak ada jawaban)" }
                    history.put(JSONObject().put("role", "assistant").put("content", t)); t
                } else { history.remove(history.length() - 1); "Error ${c.responseCode}: $resp" }
            } catch (e: Exception) { history.remove(history.length() - 1); "Gagal: ${e.message}" }
            ui.post { append("AI: $reply") }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        runCatching { wm.removeView(bubble) }; runCatching { wm.removeView(panel) }
    }
}
