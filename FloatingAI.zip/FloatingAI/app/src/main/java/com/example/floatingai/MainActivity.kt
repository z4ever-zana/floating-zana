package com.example.floatingai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply { text = "Floating AI"; textSize = 24f })
        root.addView(TextView(this).apply { text = "1) Masukkan API key Anthropic\n2) Izinkan 'Tampil di atas aplikasi lain'\n3) Mulai" })
        val key = EditText(this).apply {
            hint = "sk-ant-..."; setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(key)
        root.addView(Button(this).apply {
            text = "Mulai bubble AI"
            setOnClickListener {
                prefs.edit().putString("key", key.text.toString().trim()).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(context, "Aktifkan izin lalu tekan Mulai lagi", Toast.LENGTH_LONG).show()
                } else {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    startForegroundService(Intent(this@MainActivity, FloatingService::class.java))
                    moveTaskToBack(true)
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Hentikan"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        })
        setContentView(root)
    }
}
