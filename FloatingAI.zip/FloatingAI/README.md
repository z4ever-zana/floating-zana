# Floating AI (Android)
Bubble AI yang mengambang di atas semua aplikasi.

## Cara build
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Hubungkan HP (USB debugging aktif) lalu klik Run.
3. Buka app, isi API key Anthropic (console.anthropic.com), tekan "Mulai bubble AI".
4. Aktifkan izin "Tampil di atas aplikasi lain", kembali, tekan "Mulai" lagi.

## Pemakaian
- Geser bubble "AI" ke mana saja. Ketuk untuk membuka chat. Tombol – untuk mengecilkan, ✕ untuk menutup.
- Model diubah di FloatingService.kt (konstanta MODEL).

## Catatan
- API key disimpan di SharedPreferences di HP. Untuk rilis publik, lebih aman lewat server proxy.
- Bot ini tidak membaca isi layar aplikasi lain; itu butuh AccessibilityService/MediaProjection.

## Fitur tambahan
- Tombol 📷: pilih foto soal dari galeri, lalu tulis pertanyaan (atau langsung Kirim) dan AI membaca gambarnya.
- Web search: AI bisa mencari info terbaru (maks 3 pencarian per pesan). Fitur ini harus diaktifkan di
  Anthropic Console (Settings > Privacy > Web search) untuk organisasi API key Anda.
